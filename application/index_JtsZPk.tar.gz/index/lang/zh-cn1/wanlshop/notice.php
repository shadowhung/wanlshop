<?php

return [
    'Id' => 'ID',
    'User_id' => '用戶ID',
    'Shop_id' => '店鋪ID',
    'Title' => '消息標題',
    'Content' => '消息內容',
    'Type' => '分類',
    'Modules' => '類型',
    'Modules deliver' => '發貨提示',
    'Modules sign' => '簽收',
    'Modules agree' => '同意退款',
    'Modules refuse' => '拒絕退款',
    'Modules live' => '直播',
    'Modules new' => '商家上新',
    'Modules_id' => '所屬ID',
    'Createtime' => '創建時間',
    'Updatetime' => '更新時間',
    'Deletetime' => '删除時間',
    'Status' => '狀態'
];
/*return [
    'Id'                    => 'ID',
    'User_id'               => '用户ID',
    'Shop_id'               => '店铺ID',
    'Title'                 => '消息标题',
    'Content'               => '消息内容',
    'Type'                  => '分类',
    'Modules'               => '类型',
    'Modules deliver'       => '发货提示',
    'Modules sign'          => '签收',
    'Modules agree'         => '同意退款',
    'Modules refuse'        => '拒绝退款',
    'Modules live'          => '直播',
    'Modules new'           => '商家上新',
    'Modules_id'            => '所属ID',
    'Createtime'            => '创建时间',
    'Updatetime'            => '更新时间',
    'Deletetime'            => '删除时间',
    'Status'                => '状态'
];*/
