<?php

return [
    'Id' => 'ID',
    'Name' => '名稱',
    'Icon' => '圖標',
    'Class' => '類名',
    'Createtime' => '創建時間',
    'Updatetime' => '更新時間',
    'Deletetime' => '删除時間',
    'Weigh' => '權重',
    'Status' => '狀態'
];
/*return [
    'Id'         => 'ID',
    'Name'       => '名称',

	'Icon'       => '图标',
    'Class'      => '类名',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Weigh'      => '权重',
    'Status'     => '状态'
];*/
