<?php

return [
    'Id' => 'ID',
    'User_id' =>'ユーザーID',
    'Shop_id' =>'商店ID',
    'Title' =>'情報見出し',
    'Content' =>'情報内容',
    'Type' =>'分類',
    'Modules' =>'タイプ',
    'Modules deliver' =>'は出荷してにヒントを与えて',
    'Modules sign' =>'はを署名して受け取って',
    'Modules agree' =>'は返金に賛成して',
    'Modules refuse' =>'は返金を拒絶して',
    'Modules live' =>'はを生放送して',
    'Modules new' =>'商店は新しいに行って',
    'Modules_id' =>'所属ID',
    'Createtime' =>'創建時間',
    'Updatetime' =>'更新時間',
    'Deletetime' => '?時間を割って',
    'Status' =>'状態'
];
/*return [
    'Id'                    => 'ID',
    'User_id'               => '用户ID',
    'Shop_id'               => '店铺ID',
    'Title'                 => '消息标题',
    'Content'               => '消息内容',
    'Type'                  => '分类',
    'Modules'               => '类型',
    'Modules deliver'       => '发货提示',
    'Modules sign'          => '签收',
    'Modules agree'         => '同意退款',
    'Modules refuse'        => '拒绝退款',
    'Modules live'          => '直播',
    'Modules new'           => '商家上新',
    'Modules_id'            => '所属ID',
    'Createtime'            => '创建时间',
    'Updatetime'            => '更新时间',
    'Deletetime'            => '删除时间',
    'Status'                => '状态'
];*/
