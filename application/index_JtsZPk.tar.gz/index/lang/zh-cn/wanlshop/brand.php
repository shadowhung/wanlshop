<?php
return [
    'Id' => 'ID',
    'Admin_id' => '管理員ID',
    'Shop_id' => '商人ID',
    'Category_id' => 'カテゴリー',
    'Name' => 'ブランド名',
    'Image' => '画像',
    'Content' => '前書き',
    'Weigh' => '重み',
    'Switch' => '有効にするかどうか',
    'Createtime' => '作成時間',
    'Updatetime' => '更新時間',
    'Deletetime' => '削除時間',
    'Status' => '状態',
    'State' => '状態値',
    'State 0' => '監査中',
    'State 1' => '監査済み',
    'Category.name' => '種別名'
];
/*return [
    'Id'           => 'ID',
    'Admin_id'     => '管理员ID',
    'Shop_id'      => '商家ID',
    'Category_id'  => '所属类目',
    'Name'         => '品牌名',
    'Image'        => '图片',
    'Content'      => '内容介绍',
    'Weigh'        => '权重',
    'Switch'       => '是否启用',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间',
    'Status'       => '状态',
    'State'        => '状态值',
    'State 0'      => '审核中',
    'State 1'      => '已审核',
    'Category.name' 		=> '类目名称'
];*/