<?php
return [
    'Id' => 'ID',
    'Admin_id' => '管理員ID',
    'Shop_id' => '商家ID',
    'Category_id' => '所屬類目',
    'Name' => '品牌名',
    'Image' => '圖片',
    'Content' => '內容介紹',
    'Weigh' => '權重',
    'Switch' => '是否啟用',
    'Createtime' => '記入時間',
    'Updatetime' => '更新時間',
    'Deletetime' => '删除時間',
    'Status' => '狀態',
    'State' => '狀態值',
    'State 0' => '稽核中',
    'State 1' => '已稽核',
    'Category.name' => '類目名稱'
];
/*return [
    'Id'           => 'ID',
    'Admin_id'     => '管理员ID',
    'Shop_id'      => '商家ID',
    'Category_id'  => '所属类目',
    'Name'         => '品牌名',
    'Image'        => '图片',
    'Content'      => '内容介绍',
    'Weigh'        => '权重',
    'Switch'       => '是否启用',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间',
    'Status'       => '状态',
    'State'        => '状态值',
    'State 0'      => '审核中',
    'State 1'      => '已审核',
    'Category.name' 		=> '类目名称'
];*/