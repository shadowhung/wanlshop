<?php

return [
    'Id' => 'ID',
    'Name' =>'名称',
    'Icon' =>'アイコン',
    'Class' =>'類名',
    'Createtime' =>'記入時間',
    'Updatetime' =>'更新時間',
    'Deletetime' => '?時間を割って',
    'Weigh' =>'権力の重い',
    'Status' =>'状態'
];
/*return [
    'Id'         => 'ID',
    'Name'       => '名称',

	'Icon'       => '图标',
    'Class'      => '类名',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Weigh'      => '权重',
    'Status'     => '状态'
];*/
