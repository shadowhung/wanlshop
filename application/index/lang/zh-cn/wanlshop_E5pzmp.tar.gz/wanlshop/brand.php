<?php
return [
    'Id' => 'ID',
    'Admin_id' => 'Admin ID',
    'Shop_id' => 'Shop ID',
    'Category_id' => 'Category',
    'Name' => 'Brand name',
    'Image' => 'Image',
    'Content' => 'Content',
    'Weigh' => 'Weigh',
    'Switch' => 'Switch on',
    'Createtime' => 'Create time',
    'Updatetime' => 'Update time',
    'Deletetime' => 'Delete time',
    'Status' => 'Status',
    'State' => 'Status value',
    'State 0' => 'In review',
    'State 1' => 'Review completed',
    'Category.name' => 'Category name'
];
/*return [
    'Id'           => 'ID',
    'Admin_id'     => '管理员ID',
    'Shop_id'      => '商家ID',
    'Category_id'  => '所属类目',
    'Name'         => '品牌名',
    'Image'        => '图片',
    'Content'      => '内容介绍',
    'Weigh'        => '权重',
    'Switch'       => '是否启用',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间',
    'Status'       => '状态',
    'State'        => '状态值',
    'State 0'      => '审核中',
    'State 1'      => '已审核',
    'Category.name' 		=> '类目名称'
];*/