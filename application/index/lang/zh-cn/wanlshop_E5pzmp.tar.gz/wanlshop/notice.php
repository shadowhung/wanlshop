<?php

return [
    'Id' => 'ID',
    'User_id' => 'User ID',
    'Shop_id' => 'Shop ID',
    'Title' => 'Title',
    'Content' => 'Content',
    'Type' => 'Type',
    'Modules' => '類型',
    'Modules deliver' => 'Shipping',
    'Modules sign' => 'Received',
    'Modules agree' => 'Refund accept',
    'Modules refuse' => 'Refund refuse',
    'Modules live' => 'Live',
    'Modules new' => 'New coming',
    'Modules_id' => '所屬ID',
    'Createtime' => 'Create time',
    'Updatetime' => 'Update time',
    'Deletetime' => 'Delete time',
    'Status' => 'Status'
];
/*return [
    'Id'                    => 'ID',
    'User_id'               => '用户ID',
    'Shop_id'               => '店铺ID',
    'Title'                 => '消息标题',
    'Content'               => '消息内容',
    'Type'                  => '分类',
    'Modules'               => '类型',
    'Modules deliver'       => '发货提示',
    'Modules sign'          => '签收',
    'Modules agree'         => '同意退款',
    'Modules refuse'        => '拒绝退款',
    'Modules live'          => '直播',
    'Modules new'           => '商家上新',
    'Modules_id'            => '所属ID',
    'Createtime'            => '创建时间',
    'Updatetime'            => '更新时间',
    'Deletetime'            => '删除时间',
    'Status'                => '状态'
];*/
