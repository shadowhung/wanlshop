<?php


return [
    'Id' => 'ID',
    'Shop_id' => 'Shop',
    'Pid' => 'Parent ID',
    'Name' => 'Name',
    'Image' => 'Image',
    'Flag' => 'Tag',
    'Isnav' => 'Display',
    'Createtime' => 'Create time',
    'Updatetime' => 'Update time',
    'Weigh' => 'Weigh',
    'Status' => 'Status',
    'Route' => 'Link',
    'All' => 'All',
    'Import' => 'Import',
    'Click to search %s' => 'Click to search %s',
    'Toggle menu visible' => 'Toggle menu visible',
    'Toggle sub menu' => 'Toggle sub menu',
    'Click to search %s' => 'Click to search %s',
    'Click to toggle' => 'Click to toggle',
    'Del' => 'Delete',
    'Drag to sort' => 'Drag to sort'
];


/*return [

	'Id'                  => 'ID',

	'Shop_id'             => '店铺',

	'Pid'                 => '父级类目',

	'Name'                => '类目名称',

	'Image'               => '图片',

	'Flag'                => '标志',

	'Isnav'               => '是否导航显示',

	'Createtime'          => '创建时间',

	'Updatetime'          => '更新时间',

	'Weigh'               => '权重',

	'Status'              => '状态',

	'Route'              => '链接地址',

	// 追加

	'All'                 => '全部',

	'Import'              => '导入',

	'Click to search %s'  => '点击搜索 %s',

	'Toggle menu visible' => '点击切换菜单显示',

	'Toggle sub menu'     => '点击切换子菜单显示',

	'Click to search %s'  => '点击搜索 %s',

	'Click to toggle'     => '点击切换',

	'Del'                 => '删除',

	'Drag to sort'        => '拖动进行排序'
];*/
