<?php

return [
    'Id' => 'ID',
    'Name' => 'Name',
    'Icon' => 'Icon',
    'Class' => 'Class',
    'Createtime' => 'Create time',
    'Updatetime' => 'Update time',
    'Deletetime' => 'Delete time',
    'Weigh' => 'Weigh',
    'Status' => 'Status'
];
/*return [
    'Id'         => 'ID',
    'Name'       => '名称',

	'Icon'       => '图标',
    'Class'      => '类名',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Weigh'      => '权重',
    'Status'     => '状态'
];*/
