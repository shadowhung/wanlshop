<template>
	<view>
		<!-- 分销中心 -->
		
		<wanl-empty />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
