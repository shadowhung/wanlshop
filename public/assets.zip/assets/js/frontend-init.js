define(['frontend'], function (Frontend) {

});